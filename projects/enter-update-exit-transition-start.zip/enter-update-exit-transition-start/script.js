const intrototitle = document.getElementById('intrototitle');
const intrototitleInnerHTML = intrototitle.innerHTML
    .split(/<br>\s*/i)
    .map((text, i) => '<p style="animation-delay:' + (400 * i) + 'ms">' + text + '</p>')
    .join('');

intrototitle.innerHTML = intrototitleInnerHTML;

const target = document.getElementById('target');
const targetInnerHTML = target.innerHTML
    .split(/<br>\s*/i)
    .map((text, i) => '<p style="animation-delay:' + (2000 * i ) + 'ms">' + text + '</p>')
    .join('');

target.innerHTML = targetInnerHTML;

const introdensity = document.getElementById('introdensity');
const introdensityInnerHTML = introdensity.innerHTML
    .split(/<br>\s*/i)
    .map((text, i) => '<p style="animation-delay:' + (2000 * i + 1000) + 'ms">' + text + '</p>')
    .join('');

introdensity.innerHTML = introdensityInnerHTML;

const densitystyle = document.getElementById('densitystyle');
const densitystyleInnerHTML = densitystyle.innerHTML
    .split(/<br>\s*/i)
    .map((text, i) => '<p style="animation-delay:' + (2000 * i + 7000) + 'ms">' + text + '</p>')
    .join('');

densitystyle.innerHTML = densitystyleInnerHTML;

const forcegraphstart = document.getElementById('forcegraphstart');
const forcegraphstartInnerHTML = forcegraphstart.innerHTML
    .split(/<br>\s*/i)
    .map((text, i) => '<p style="animation-delay:' + (2000 * i) + 'ms">' + text + '</p>')
    .join('');

forcegraphstart.innerHTML = forcegraphstartInnerHTML;

var scrollpos = window.scrollY;

document.addEventListener("scroll", function () { showFunction() });

function showFunction() {
    
    if (document.documentElement.scrollTop > 394) {
        document.getElementById("intrototitle").style.display = "block";
    } else {
        document.getElementById("intrototitle").style.display = "none";
    }

    if (document.documentElement.scrollTop > 676) {
        document.getElementById("target").style.display = "block";
    } else {
        document.getElementById("target").style.display = "none";
    }


    if (document.documentElement.scrollTop > 950) {
        document.getElementById("introdensity").style.display = "block";
    } else {
        document.getElementById("introdensity").style.display = "none";
    }

    if (document.documentElement.scrollTop > 1200) {
        document.getElementById("densitystyle").style.display = "block";
    } else {
        document.getElementById("densitystyle").style.display = "none";
    }

    if (document.documentElement.scrollTop > 1200) {
        document.getElementById("densitystyle").style.display = "block";
    } else {
        document.getElementById("densitystyle").style.display = "none";
    }

    if (document.documentElement.scrollTop > 1800) {
        document.getElementById("forcegraphstart").style.display = "block";
    } else {
        document.getElementById("forcegraphstart").style.display = "none";
    }
console.log(document.documentElement.scrollTop);
}


//d3 come
let w = 1000;
let h = 1000;
let padding = 50;

d3.json("data.json").then(gotData);

let viz = d3.select("#generalcontainer")
    .append("svg")
    .style("width", w)
    .style("height", h)
    .attr("x",100)
  .attr("y",200)
  .attr("fill","none")
    .attr("class","biggeneral")
    ;


    function gotData(incomingData){
    
        let generalcirclea = generalviz.selectAll(".generalcircle").data(data).enter()
        .append('circle')
        .attr("r",5)
        .attr("fill","white")
        .attr('cx',d.time)
        .attr('cy',function(d){return yScale0(d.number)})
          .attr("opacity",0)

          let timeParseFunction = d3.timeParse("%d %b %Y");

  let timeFormat = d3.timeFormat("%d %b");
  console.log(timeParseFunction("01 Feb 2018"));
  console.log(timeFormat(timeParseFunction("01 Feb 2018")));

    }

    